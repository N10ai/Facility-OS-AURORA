# FacilityOS Aurora Operations v2.2.0

## What changed

- Business navigation reorganized into Home, CRM, Operations, Finance, Team, Reports, and Settings.
- Floating black mobile dock with compact module sheets.
- Portal users can be created inside FacilityOS.
- Portal users can be deleted inside FacilityOS.
- Added database foundations for quotes, invoices, payments, payroll, expenses, contractors, inspections, and billing subscriptions.
- Preserved Admin, Employee, and Customer portals.

## Install

```bash
unzip -o FacilityOS_Aurora_Operations_v2_2_0.zip
cp -r FacilityOS_Aurora_Operations_v2_2_0/* .
cp -r FacilityOS_Aurora_Operations_v2_2_0/.[!.]* . 2>/dev/null || true
rm -rf FacilityOS_Aurora_Operations_v2_2_0
npm install
npm run dev -- --host 0.0.0.0 --port 3000
```

Run the updated migration:

```text
database/migrations/007_aurora_operations_three_portals.sql
```

## Deploy secure user-management functions

Install/login to the Supabase CLI, link your project, then run:

```bash
supabase functions deploy create-portal-user
supabase functions deploy delete-portal-user
```

The hosted Edge Functions automatically receive the Supabase URL, anon key, and service-role environment variables. Never place the service-role key in `.env` or frontend code.

## Creating a user

Open **Team → Employees → Create user** and enter:

- full name
- email
- temporary password
- employee, manager, or customer role
- customer account when the role is Customer

## Current scope

Customers, facilities, recurring scheduling, missions, proof photos, issues, requests, portals, and user creation are operational. The additional CRM/Finance modules now have menu routes and database foundations; detailed forms and workflows will be completed module-by-module.
