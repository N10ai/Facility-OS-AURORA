# FacilityOS Aurora Operations v2.1.0

A usable single-company MVP for a cleaning/facility-services business.

## Three working portals

### Admin
- Customers
- Facilities
- Employees and customer users
- Recurring service plans
- Generate 12 months of visits
- Calendar/upcoming work
- Assign employees
- Review missions
- Verify only after checklist and before/after proof
- Issues and customer requests
- MIP starter profile

### Employee
- Today’s assigned missions
- Check in
- Mobile checklist
- Real photo uploads to Supabase Storage
- Before/after proof
- Report facility issues
- Submit mission for verification

### Customer
- Upcoming services
- Verified service history
- Before/after proof gallery
- Open issues
- Submit service requests

## Install

Keep your `.env`, then:

```bash
unzip -o FacilityOS_Aurora_Operations_v2_1_0.zip
cp -r FacilityOS_Aurora_Operations_v2_1_0/* .
cp -r FacilityOS_Aurora_Operations_v2_1_0/.[!.]* . 2>/dev/null || true
rm -rf FacilityOS_Aurora_Operations_v2_1_0

npm install
npm run dev
```

## Supabase

Run:

```text
database/migrations/007_aurora_operations_three_portals.sql
```

## First setup

1. Log in with the owner account.
2. Create the N10 Enterprise LLC workspace.
3. Go to Settings and click **Load MIP starter profile**.
4. Add your second customer and facility.
5. In Supabase Authentication, create employee and customer login users.
6. Copy each Authentication User ID.
7. In FacilityOS → Employees, connect the User ID to an Employee or Customer role.
8. Create recurring plans and generate 12 months of visits.
9. Assign the employee to the plan before generating visits.

## Important MVP security note

This version is designed for your single company and fast real-world use. The SQL policies allow authenticated workspace access and rely on portal filtering. Before selling FacilityOS as multi-company SaaS, replace them with strict tenant/role RLS policies.
