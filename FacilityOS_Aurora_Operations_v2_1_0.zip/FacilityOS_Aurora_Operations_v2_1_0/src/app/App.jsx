import { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle, ArrowLeft, Bell, Building2, CalendarDays, Camera, CheckCircle2,
  ChevronRight, CircleUserRound, ClipboardCheck, Clock, FileText, Home, Image,
  LogOut, Menu, Plus, Search, Settings, ShieldCheck, Sparkles, UsersRound, Wrench, X
} from 'lucide-react';
import { configured, supabase } from '../services/supabase';
import {
  createCompany, createCustomer, createCustomerRequest, createFacility, createIssue,
  createPerson, createServicePlan, generateVisits, getMyProfile, loadWorkspace,
  saveMyProfile, seedMIP, toggleTask, updateVisit, uploadProof
} from '../services/api';

const empty = {
  customers:[], facilities:[], people:[], plans:[], visits:[],
  tasks:[], proof:[], issues:[], requests:[]
};

function Modal({open,title,onClose,children}) {
  if(!open) return null;
  return <div className="modalBackdrop">
    <section className="modal">
      <button className="icon close" onClick={onClose}><X size={18}/></button>
      <h2>{title}</h2>
      {children}
    </section>
  </div>;
}

function Button({children,variant='primary',...props}) {
  return <button className={`btn ${variant}`} {...props}>{children}</button>;
}

function Stat({label,value,note,icon:Icon,tone=''}) {
  return <div className={`stat ${tone}`}>
    {Icon && <div className="statIcon"><Icon size={19}/></div>}
    <strong>{value}</strong><span>{label}</span><small>{note}</small>
  </div>;
}

function Login({onReady}) {
  const [mode,setMode]=useState('login');
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const [message,setMessage]=useState('');

  async function submit() {
    const result = mode==='login'
      ? await supabase.auth.signInWithPassword({email,password})
      : await supabase.auth.signUp({email,password});
    if(result.error) return setMessage(result.error.message);
    setMessage(mode==='login'?'Logged in.':'Account created. Confirm email if required.');
    onReady?.();
  }

  if(!configured) return <div className="loginPage"><div className="loginCard"><div className="logoMark">F</div><h1>FacilityOS</h1><p>Add your Supabase URL and anon key to <code>.env</code>.</p></div></div>;

  return <div className="loginPage">
    <div className="loginCard">
      <div className="logoMark">F</div>
      <p className="eyebrow">Aurora Operations</p>
      <h1>Run your cleaning company from one workspace.</h1>
      <p>Admin planning, employee execution, and customer visibility.</p>
      <div className="segmented"><button className={mode==='login'?'active':''} onClick={()=>setMode('login')}>Login</button><button className={mode==='signup'?'active':''} onClick={()=>setMode('signup')}>Create account</button></div>
      <label>Email<input value={email} onChange={e=>setEmail(e.target.value)}/></label>
      <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)}/></label>
      <Button onClick={submit}>{mode==='login'?'Login':'Create account'}</Button>
      {message && <div className="notice">{message}</div>}
    </div>
  </div>;
}

function Setup({session,onDone}) {
  const [name,setName]=useState('N10 Enterprise LLC');
  const [fullName,setFullName]=useState('Ignacio');
  const [message,setMessage]=useState('');

  async function create() {
    const {data,error}=await createCompany(session.user,name);
    if(error) return setMessage(error.message);
    await saveMyProfile(session.user,{full_name:fullName,role:'owner',company_id:data.id});
    onDone();
  }

  return <div className="loginPage">
    <div className="loginCard">
      <div className="logoMark">F</div>
      <p className="eyebrow">One-time setup</p>
      <h1>Create your operating workspace.</h1>
      <label>Your name<input value={fullName} onChange={e=>setFullName(e.target.value)}/></label>
      <label>Company<input value={name} onChange={e=>setName(e.target.value)}/></label>
      <Button onClick={create}>Create workspace</Button>
      {message && <div className="notice">{message}</div>}
    </div>
  </div>;
}

const adminNav = [
  ['overview','Overview',Home],['customers','Customers',UsersRound],['facilities','Facilities',Building2],
  ['calendar','Calendar',CalendarDays],['employees','Employees',CircleUserRound],
  ['issues','Issues',AlertTriangle],['settings','Settings',Settings]
];
const employeeNav = [['employee-home','Today',Home],['employee-schedule','Schedule',CalendarDays],['employee-history','History',CheckCircle2]];
const customerNav = [['customer-home','Overview',Home],['customer-schedule','Schedule',CalendarDays],['customer-proof','Service Proof',Image],['customer-requests','Requests',Wrench]];

function Shell({profile,portal,setPortal,page,setPage,children}) {
  const [mobile,setMobile]=useState(false);
  const nav = portal==='admin'?adminNav:portal==='employee'?employeeNav:customerNav;

  return <div className="appShell">
    <aside className="side">
      <div className="brand"><div className="logoMark small">F</div><div><strong>FacilityOS</strong><span>Aurora Operations</span></div></div>
      <div className="portalSwitch">
        {['admin','employee','customer'].map(p=><button key={p} className={portal===p?'active':''} onClick={()=>{setPortal(p);setPage(p==='admin'?'overview':p==='employee'?'employee-home':'customer-home')}}>{p}</button>)}
      </div>
      <nav>{nav.map(([key,label,Icon])=><button key={key} className={page===key?'navItem active':'navItem'} onClick={()=>setPage(key)}><Icon size={18}/><span>{label}</span></button>)}</nav>
      <div className="profileCard"><div className="avatar">{profile.full_name?.slice(0,1)||'U'}</div><div><strong>{profile.full_name}</strong><span>{profile.role}</span></div></div>
    </aside>

    {mobile && <div className="mobileOverlay" onClick={()=>setMobile(false)}/>}
    <main className="main">
      <header className="top">
        <button className="icon mobileMenu" onClick={()=>setMobile(true)}><Menu size={20}/></button>
        <div><span>FacilityOS</span><strong>{nav.find(x=>x[0]===page)?.[1]||'Workspace'}</strong></div>
        <button className="search"><Search size={18}/><span>Search anything...</span></button>
        <button className="icon"><Bell size={18}/></button>
        <button className="avatarButton">{profile.full_name?.slice(0,1)||'U'}</button>
      </header>
      <section className="canvas">{children}</section>
    </main>
  </div>;
}

function AdminOverview({data,setPage}) {
  const today=new Date().toISOString().slice(0,10);
  const todayVisits=data.visits.filter(v=>v.scheduled_date===today);
  const openIssues=data.issues.filter(i=>i.status!=='closed');
  const activeEmployees=data.people.filter(p=>p.role==='employee');
  const activeCustomers=data.customers.length;

  return <div className="page">
    <div className="pageHeader"><div><p className="eyebrow">Operations control</p><h1>Good morning, Ignacio.</h1><p>Here’s what needs attention across your cleaning operation.</p></div><Button onClick={()=>setPage('calendar')}><Plus size={16}/> Plan service</Button></div>
    <div className="stats">
      <Stat icon={CalendarDays} label="Visits today" value={todayVisits.length} note={`${data.visits.length} scheduled total`}/>
      <Stat icon={UsersRound} label="Customers" value={activeCustomers} note="Active accounts" tone="pastelBlue"/>
      <Stat icon={CircleUserRound} label="Employees" value={activeEmployees.length} note="Available team" tone="pastelGreen"/>
      <Stat icon={AlertTriangle} label="Open issues" value={openIssues.length} note="Needs review" tone="pastelYellow"/>
    </div>
    <div className="grid2">
      <section className="panel large">
        <div className="panelTitle"><div><p className="eyebrow">Today</p><h2>Mission schedule</h2></div><button className="link" onClick={()=>setPage('calendar')}>View calendar</button></div>
        <div className="rows">
          {todayVisits.map(v=><VisitRow key={v.id} visit={v} data={data}/>)}
          {!todayVisits.length && <Empty title="No visits today" text="Create a service plan and generate visits."/>}
        </div>
      </section>
      <section className="darkCard">
        <Sparkles size={24}/>
        <h2>Operations focus</h2>
        <p>Use recurring plans to schedule the year, assign employees, and require photo proof before a mission can be verified.</p>
        <Button variant="light" onClick={()=>setPage('calendar')}>Open planning</Button>
      </section>
    </div>
    <div className="grid2">
      <section className="panel">
        <div className="panelTitle"><h2>Recent issues</h2></div>
        {openIssues.slice(0,5).map(i=><div className="simpleRow" key={i.id}><div className={`priority ${i.priority}`}/><div><strong>{i.title}</strong><span>{i.priority} · {i.status}</span></div></div>)}
        {!openIssues.length && <p>No open issues.</p>}
      </section>
      <section className="panel">
        <div className="panelTitle"><h2>Customer requests</h2></div>
        {data.requests.slice(0,5).map(r=><div className="simpleRow" key={r.id}><Wrench size={18}/><div><strong>{r.title}</strong><span>{r.status}</span></div></div>)}
        {!data.requests.length && <p>No customer requests.</p>}
      </section>
    </div>
  </div>;
}

function VisitRow({visit,data,onOpen}) {
  const customer=data.customers.find(x=>x.id===visit.customer_id);
  const facility=data.facilities.find(x=>x.id===visit.facility_id);
  const employee=data.people.find(x=>x.id===visit.assigned_to_profile_id);
  return <button className="visitRow" onClick={()=>onOpen?.(visit)}>
    <div className="dateTile"><strong>{visit.scheduled_time||'—'}</strong><span>{visit.scheduled_date}</span></div>
    <div><strong>{visit.title||'Service visit'}</strong><span>{customer?.name||'Customer'} · {facility?.name||'Facility'}</span></div>
    <div className="employeeChip">{employee?.full_name||'Unassigned'}</div>
    <div className={`status ${visit.status}`}>{visit.status}</div>
    <ChevronRight size={18}/>
  </button>;
}

function Empty({title,text}) {
  return <div className="empty"><div className="emptyIcon"><Sparkles size={22}/></div><strong>{title}</strong><p>{text}</p></div>;
}

function CustomersPage({data,companyId,reload}) {
  const [open,setOpen]=useState(false);
  const [form,setForm]=useState({name:'',customer_type:'commercial',email:'',phone:'',address:'',monthly_value:''});
  const [message,setMessage]=useState('');

  async function save() {
    const {error}=await createCustomer(companyId,form);
    if(error) return setMessage(error.message);
    setOpen(false); setForm({name:'',customer_type:'commercial',email:'',phone:'',address:'',monthly_value:''}); reload();
  }

  return <div className="page">
    <div className="pageHeader"><div><p className="eyebrow">CRM</p><h1>Customers</h1><p>Manage your cleaning accounts and their facilities.</p></div><Button onClick={()=>setOpen(true)}><Plus size={16}/> New customer</Button></div>
    <div className="cards">
      {data.customers.map(c=>{
        const facilities=data.facilities.filter(f=>f.customer_id===c.id);
        const visits=data.visits.filter(v=>v.customer_id===c.id);
        return <article className="objectCard" key={c.id}><div className="objectHead"><div className="objectIcon">{c.name.slice(0,1)}</div><div className="status active">active</div></div><h2>{c.name}</h2><p>{c.customer_type||'commercial'}</p><div className="miniStats"><span><b>{facilities.length}</b> facilities</span><span><b>{visits.length}</b> visits</span><span><b>${c.monthly_value||0}</b>/mo</span></div></article>
      })}
      {!data.customers.length && <Empty title="No customers" text="Create your first customer."/>}
    </div>
    <Modal open={open} title="New customer" onClose={()=>setOpen(false)}><div className="form">
      <label>Name<input value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label>
      <div className="form2"><label>Type<select value={form.customer_type} onChange={e=>setForm({...form,customer_type:e.target.value})}><option>commercial</option><option>logistics</option><option>medical</option><option>retail</option></select></label><label>Monthly value<input type="number" value={form.monthly_value} onChange={e=>setForm({...form,monthly_value:e.target.value})}/></label></div>
      <div className="form2"><label>Email<input value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></label><label>Phone<input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/></label></div>
      <label>Address<input value={form.address} onChange={e=>setForm({...form,address:e.target.value})}/></label>
      {message&&<div className="notice">{message}</div>}<Button onClick={save}>Create customer</Button>
    </div></Modal>
  </div>;
}

function FacilitiesPage({data,companyId,reload}) {
  const [open,setOpen]=useState(false);
  const [form,setForm]=useState({customer_id:'',name:'',facility_type:'office',address:'',access_notes:'',restroom_count:0,floor_type:'',estimated_minutes:90});
  const [message,setMessage]=useState('');

  async function save() {
    const {error}=await createFacility(companyId,form);
    if(error) return setMessage(error.message);
    setOpen(false); reload();
  }

  return <div className="page">
    <div className="pageHeader"><div><p className="eyebrow">Digital twins</p><h1>Facilities</h1><p>Each site stores access, cleaning conditions, schedule, proof, and issues.</p></div><Button onClick={()=>setOpen(true)}><Plus size={16}/> New facility</Button></div>
    <div className="cards">
      {data.facilities.map(f=>{
        const customer=data.customers.find(c=>c.id===f.customer_id);
        return <article className="objectCard" key={f.id}><div className="objectHead"><div className="objectIcon"><Building2 size={21}/></div><div className="status active">{f.status}</div></div><h2>{f.name}</h2><p>{customer?.name} · {f.facility_type}</p><div className="miniStats"><span><b>{f.restroom_count||0}</b> restrooms</span><span><b>{f.estimated_minutes||0}</b> min</span></div><div className="softBox"><strong>Floor</strong><span>{f.floor_type||'Not set'}</span></div></article>
      })}
    </div>
    <Modal open={open} title="New facility" onClose={()=>setOpen(false)}><div className="form">
      <label>Customer<select value={form.customer_id} onChange={e=>setForm({...form,customer_id:e.target.value})}><option value="">Select...</option>{data.customers.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
      <label>Name<input value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label>
      <div className="form2"><label>Type<select value={form.facility_type} onChange={e=>setForm({...form,facility_type:e.target.value})}><option>office</option><option>warehouse</option><option>medical</option><option>retail</option></select></label><label>Restrooms<input type="number" value={form.restroom_count} onChange={e=>setForm({...form,restroom_count:e.target.value})}/></label></div>
      <div className="form2"><label>Floor type<input value={form.floor_type} onChange={e=>setForm({...form,floor_type:e.target.value})}/></label><label>Estimated minutes<input type="number" value={form.estimated_minutes} onChange={e=>setForm({...form,estimated_minutes:e.target.value})}/></label></div>
      <label>Address<input value={form.address} onChange={e=>setForm({...form,address:e.target.value})}/></label>
      <label>Access and cleaning notes<textarea value={form.access_notes} onChange={e=>setForm({...form,access_notes:e.target.value})}/></label>
      {message&&<div className="notice">{message}</div>}<Button onClick={save}>Create facility</Button>
    </div></Modal>
  </div>;
}

function EmployeesPage({data,companyId,reload}) {
  const [open,setOpen]=useState(false);
  const [form,setForm]=useState({user_id:'',full_name:'',role:'employee',phone:'',customer_id:''});
  const [message,setMessage]=useState('');

  async function save() {
    const {error}=await createPerson(companyId,form);
    if(error) return setMessage(error.message);
    setOpen(false); reload();
  }

  return <div className="page">
    <div className="pageHeader"><div><p className="eyebrow">Team</p><h1>Employees & portal users</h1><p>Connect employee and customer logins to the correct portal.</p></div><Button onClick={()=>setOpen(true)}><Plus size={16}/> Add portal user</Button></div>
    <section className="panel">
      {data.people.map(p=><div className="personRow" key={p.id}><div className="avatar">{p.full_name?.slice(0,1)||'U'}</div><div><strong>{p.full_name||p.id}</strong><span>{p.role} · {p.phone||'No phone'}</span></div><div className={`status ${p.status||'active'}`}>{p.status||'active'}</div></div>)}
    </section>
    <Modal open={open} title="Connect portal user" onClose={()=>setOpen(false)}><div className="form">
      <div className="notice">Create the user under Supabase → Authentication → Users first. Then paste that User ID here.</div>
      <label>Supabase User ID<input value={form.user_id} onChange={e=>setForm({...form,user_id:e.target.value})}/></label>
      <label>Full name<input value={form.full_name} onChange={e=>setForm({...form,full_name:e.target.value})}/></label>
      <div className="form2"><label>Role<select value={form.role} onChange={e=>setForm({...form,role:e.target.value})}><option value="employee">Employee</option><option value="customer">Customer</option><option value="manager">Manager</option></select></label><label>Phone<input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/></label></div>
      {form.role==='customer'&&<label>Customer account<select value={form.customer_id} onChange={e=>setForm({...form,customer_id:e.target.value})}><option value="">Select...</option>{data.customers.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label>}
      {message&&<div className="notice">{message}</div>}<Button onClick={save}>Connect user</Button>
    </div></Modal>
  </div>;
}

function CalendarPage({data,companyId,reload}) {
  const [planOpen,setPlanOpen]=useState(false);
  const [selectedPlan,setSelectedPlan]=useState(null);
  const [mission,setMission]=useState(null);
  const [form,setForm]=useState({customer_id:'',facility_id:'',name:'Weekly Cleaning',frequency:'weekly',weekdays:[6],start_date:new Date().toISOString().slice(0,10),default_time:'09:00',assigned_to_profile_id:'',estimated_minutes:90,visit_price:0});
  const [message,setMessage]=useState('');

  const facilities=data.facilities.filter(f=>!form.customer_id||f.customer_id===form.customer_id);
  const employees=data.people.filter(p=>p.role==='employee'||p.role==='manager');

  async function savePlan() {
    const {data:plan,error}=await createServicePlan(companyId,form);
    if(error) return setMessage(error.message);
    setPlanOpen(false); setSelectedPlan(plan); reload();
  }

  async function generate(plan) {
    setMessage('');
    const {error}=await generateVisits(companyId,plan,12);
    if(error) return setMessage(error.message);
    setMessage('Generated the next 12 months of visits.');
    reload();
  }

  return <div className="page">
    <div className="pageHeader"><div><p className="eyebrow">Planning</p><h1>Calendar & recurring services</h1><p>Create a service plan once and generate the year.</p></div><Button onClick={()=>setPlanOpen(true)}><Plus size={16}/> New service plan</Button></div>
    {message&&<div className="notice">{message}</div>}
    <div className="grid2">
      <section className="panel">
        <div className="panelTitle"><h2>Service plans</h2></div>
        {data.plans.map(p=><div className="planRow" key={p.id}><div><strong>{p.name}</strong><span>{p.frequency} · {p.default_time} · ${p.visit_price||0}/visit</span></div><Button variant="secondary" onClick={()=>generate(p)}>Generate 12 months</Button></div>)}
        {!data.plans.length&&<Empty title="No service plans" text="Create your first recurring plan."/>}
      </section>
      <section className="panel">
        <div className="panelTitle"><h2>Upcoming visits</h2></div>
        <div className="rows">{data.visits.slice(0,12).map(v=><VisitRow key={v.id} visit={v} data={data} onOpen={setMission}/>)}</div>
      </section>
    </div>
    <Modal open={planOpen} title="New recurring service plan" onClose={()=>setPlanOpen(false)}><div className="form">
      <label>Customer<select value={form.customer_id} onChange={e=>setForm({...form,customer_id:e.target.value,facility_id:''})}><option value="">Select...</option>{data.customers.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
      <label>Facility<select value={form.facility_id} onChange={e=>setForm({...form,facility_id:e.target.value})}><option value="">Select...</option>{facilities.map(f=><option key={f.id} value={f.id}>{f.name}</option>)}</select></label>
      <label>Plan name<input value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label>
      <div className="form2"><label>Frequency<select value={form.frequency} onChange={e=>setForm({...form,frequency:e.target.value})}><option value="weekly">Weekly</option><option value="biweekly">Every 2 weeks</option><option value="monthly">Monthly</option><option value="quarterly">Quarterly</option></select></label><label>Start date<input type="date" value={form.start_date} onChange={e=>setForm({...form,start_date:e.target.value})}/></label></div>
      <div className="form2"><label>Default time<input type="time" value={form.default_time} onChange={e=>setForm({...form,default_time:e.target.value})}/></label><label>Employee<select value={form.assigned_to_profile_id} onChange={e=>setForm({...form,assigned_to_profile_id:e.target.value})}><option value="">Unassigned</option>{employees.map(p=><option key={p.id} value={p.id}>{p.full_name}</option>)}</select></label></div>
      <div className="form2"><label>Estimated minutes<input type="number" value={form.estimated_minutes} onChange={e=>setForm({...form,estimated_minutes:e.target.value})}/></label><label>Price per visit<input type="number" value={form.visit_price} onChange={e=>setForm({...form,visit_price:e.target.value})}/></label></div>
      <label>Weekdays<select multiple value={form.weekdays.map(String)} onChange={e=>setForm({...form,weekdays:Array.from(e.target.selectedOptions).map(o=>Number(o.value))})}><option value="1">Monday</option><option value="2">Tuesday</option><option value="3">Wednesday</option><option value="4">Thursday</option><option value="5">Friday</option><option value="6">Saturday</option><option value="0">Sunday</option></select></label>
      <Button onClick={savePlan}>Create plan</Button>
    </div></Modal>
    <Modal open={!!mission} title="Mission details" onClose={()=>setMission(null)}>{mission&&<AdminMission visit={mission} data={data} reload={reload}/>}</Modal>
  </div>;
}

function AdminMission({visit,data,reload}) {
  const [message,setMessage]=useState('');
  const tasks=data.tasks.filter(t=>t.service_visit_id===visit.id);
  const proof=data.proof.filter(p=>p.service_visit_id===visit.id);

  async function markVerified() {
    const incomplete=tasks.some(t=>t.status!=='completed');
    const before=proof.some(p=>p.proof_type==='before');
    const after=proof.some(p=>p.proof_type==='after');
    if(incomplete||!before||!after) return setMessage('Cannot verify until all tasks and before/after proof are complete.');
    await updateVisit(visit.id,{status:'completed',verification_status:'verified',completed_at:new Date().toISOString()});
    setMessage('Mission verified.'); reload();
  }

  return <div className="missionAdmin">
    <div className="missionProgress"><strong>{tasks.filter(t=>t.status==='completed').length}/{tasks.length}</strong><span>tasks complete</span></div>
    <div className="proofGrid">{proof.map(p=><img src={p.file_url} key={p.id}/>)}</div>
    {message&&<div className="notice">{message}</div>}
    <Button onClick={markVerified}><ShieldCheck size={17}/> Verify mission</Button>
  </div>;
}

function IssuesPage({data}) {
  return <div className="page"><div className="pageHeader"><div><p className="eyebrow">Facility intelligence</p><h1>Issues</h1><p>Problems reported by employees and customers.</p></div></div><section className="panel">{data.issues.map(i=><div className="issueRow" key={i.id}><div className={`priority ${i.priority}`}/><div><strong>{i.title}</strong><span>{i.description||'No description'}</span></div><div className={`status ${i.status}`}>{i.status}</div></div>)}{!data.issues.length&&<Empty title="No issues" text="Reported problems will appear here."/>}</section></div>;
}

function SettingsPage({companyId,reload}) {
  const [message,setMessage]=useState('');
  async function loadMIP() {
    const {error}=await seedMIP(companyId);
    setMessage(error?error.message:'MIP customer, facility, and weekly plan were created.');
    reload();
  }
  return <div className="page"><div className="pageHeader"><div><p className="eyebrow">Workspace</p><h1>Settings</h1><p>Initialize your real operating data.</p></div></div><section className="panel"><h2>MIP starter profile</h2><p>Creates MIP Cargo Express, its office facility, 3 restrooms, LVP floors, 150-minute estimate, and weekly cleaning plan.</p><Button onClick={loadMIP}>Load MIP starter profile</Button>{message&&<div className="notice">{message}</div>}</section></div>;
}

function EmployeeHome({profile,data,reload}) {
  const [mission,setMission]=useState(null);
  const today=new Date().toISOString().slice(0,10);
  const mine=data.visits.filter(v=>v.assigned_to_profile_id===profile.id);
  const todayMine=mine.filter(v=>v.scheduled_date===today);

  if(mission) return <EmployeeMission profile={profile} visit={mission} data={data} reload={reload} onBack={()=>setMission(null)}/>;

  return <div className="page">
    <div className="pageHeader"><div><p className="eyebrow">Employee portal</p><h1>Today’s missions</h1><p>Complete each mission with checklist and photo proof.</p></div></div>
    <div className="missionCards">
      {todayMine.map(v=><button className="missionCard" key={v.id} onClick={()=>setMission(v)}><div className="missionTime">{v.scheduled_time||'—'}</div><h2>{v.title}</h2><p>{data.facilities.find(f=>f.id===v.facility_id)?.name}</p><div className={`status ${v.status}`}>{v.status}</div></button>)}
      {!todayMine.length&&<Empty title="No missions today" text="Assigned work will appear here."/>}
    </div>
    <section className="panel"><h2>Upcoming</h2>{mine.filter(v=>v.scheduled_date>today).slice(0,8).map(v=><VisitRow key={v.id} visit={v} data={data} onOpen={setMission}/>)}</section>
  </div>;
}

function EmployeeMission({profile,visit,data,reload,onBack}) {
  const [message,setMessage]=useState('');
  const [issueOpen,setIssueOpen]=useState(false);
  const [issue,setIssue]=useState({title:'',description:'',priority:'medium'});
  const tasks=data.tasks.filter(t=>t.service_visit_id===visit.id);
  const proof=data.proof.filter(p=>p.service_visit_id===visit.id);
  const facility=data.facilities.find(f=>f.id===visit.facility_id);

  async function begin() {
    await updateVisit(visit.id,{status:'in_progress',check_in_at:new Date().toISOString()}); reload();
  }
  async function doTask(task) { await toggleTask(task); reload(); }
  async function fileChange(e,type) {
    const file=e.target.files?.[0]; if(!file) return;
    const {error}=await uploadProof(profile.company_id,visit.id,profile.id,file,type);
    setMessage(error?error.message:`${type} photo uploaded.`); reload();
  }
  async function submitIssue() {
    const {error}=await createIssue(profile.company_id,{...issue,customer_id:visit.customer_id,facility_id:visit.facility_id,service_visit_id:visit.id},profile.id);
    if(error) return setMessage(error.message);
    setIssueOpen(false); setIssue({title:'',description:'',priority:'medium'}); reload();
  }
  async function finish() {
    const allDone=tasks.length&&tasks.every(t=>t.status==='completed');
    const hasBefore=proof.some(p=>p.proof_type==='before');
    const hasAfter=proof.some(p=>p.proof_type==='after');
    if(!allDone||!hasBefore||!hasAfter) return setMessage('Complete all tasks and upload at least one before and one after photo.');
    await updateVisit(visit.id,{status:'awaiting_verification',verification_status:'pending',check_out_at:new Date().toISOString()});
    setMessage('Mission submitted for manager verification.'); reload();
  }

  return <div className="page missionPage">
    <button className="back" onClick={onBack}><ArrowLeft size={18}/> Back</button>
    <div className="missionHero"><div><p className="eyebrow">Mission</p><h1>{visit.title}</h1><p>{facility?.name} · {visit.scheduled_time}</p></div><div className={`status ${visit.status}`}>{visit.status}</div></div>
    <section className="infoStrip"><Clock size={18}/><div><strong>{visit.estimated_minutes||facility?.estimated_minutes||90} minutes</strong><span>{facility?.access_notes||'No access notes'}</span></div></section>
    {visit.status==='scheduled'&&<Button onClick={begin}>Check in and start</Button>}
    <div className="proofUploadGrid">
      <label className="uploadTile"><Camera size={28}/><strong>Before photos</strong><span>{proof.filter(p=>p.proof_type==='before').length} uploaded</span><input type="file" accept="image/*" capture="environment" onChange={e=>fileChange(e,'before')}/></label>
      <label className="uploadTile"><Camera size={28}/><strong>After photos</strong><span>{proof.filter(p=>p.proof_type==='after').length} uploaded</span><input type="file" accept="image/*" capture="environment" onChange={e=>fileChange(e,'after')}/></label>
    </div>
    <section className="panel"><div className="panelTitle"><h2>Checklist</h2><span>{tasks.filter(t=>t.status==='completed').length}/{tasks.length}</span></div>{tasks.map(t=><label className="task" key={t.id}><input type="checkbox" checked={t.status==='completed'} onChange={()=>doTask(t)}/><div><strong>{t.title}</strong>{t.requires_proof&&<span>Proof required</span>}</div></label>)}</section>
    <div className="buttonRow"><Button variant="secondary" onClick={()=>setIssueOpen(true)}><AlertTriangle size={17}/> Report issue</Button><Button onClick={finish}><CheckCircle2 size={17}/> Submit mission</Button></div>
    {message&&<div className="notice">{message}</div>}
    <Modal open={issueOpen} title="Report facility issue" onClose={()=>setIssueOpen(false)}><div className="form"><label>Title<input value={issue.title} onChange={e=>setIssue({...issue,title:e.target.value})}/></label><label>Description<textarea value={issue.description} onChange={e=>setIssue({...issue,description:e.target.value})}/></label><label>Priority<select value={issue.priority} onChange={e=>setIssue({...issue,priority:e.target.value})}><option>low</option><option>medium</option><option>high</option><option>urgent</option></select></label><Button onClick={submitIssue}>Submit issue</Button></div></Modal>
  </div>;
}

function CustomerHome({profile,data}) {
  const customer=data.customers.find(c=>c.id===profile.customer_id);
  const facilities=data.facilities.filter(f=>f.customer_id===profile.customer_id);
  const visits=data.visits.filter(v=>v.customer_id===profile.customer_id);
  const completed=visits.filter(v=>v.verification_status==='verified');
  const upcoming=visits.filter(v=>v.status==='scheduled').slice(0,5);
  const issues=data.issues.filter(i=>i.customer_id===profile.customer_id&&i.status!=='closed');

  return <div className="page">
    <div className="pageHeader"><div><p className="eyebrow">Customer portal</p><h1>Welcome, {customer?.name||profile.full_name}.</h1><p>See upcoming service, verified proof, and facility issues.</p></div></div>
    <div className="stats"><Stat icon={CalendarDays} label="Upcoming visits" value={upcoming.length} note="Scheduled"/><Stat icon={CheckCircle2} label="Verified services" value={completed.length} note="Completed"/><Stat icon={Building2} label="Facilities" value={facilities.length} note="Managed"/><Stat icon={AlertTriangle} label="Open issues" value={issues.length} note="In progress"/></div>
    <div className="grid2"><section className="panel"><h2>Upcoming service</h2>{upcoming.map(v=><VisitRow key={v.id} visit={v} data={data}/>)}</section><section className="darkCard"><ShieldCheck size={24}/><h2>Proof of service</h2><p>Completed visits become visible after manager verification.</p></section></div>
  </div>;
}

function CustomerProof({profile,data}) {
  const visits=data.visits.filter(v=>v.customer_id===profile.customer_id&&v.verification_status==='verified');
  return <div className="page"><div className="pageHeader"><div><p className="eyebrow">Verified work</p><h1>Service proof</h1><p>Before and after photos for completed visits.</p></div></div>{visits.map(v=>{const proof=data.proof.filter(p=>p.service_visit_id===v.id);return <section className="panel" key={v.id}><div className="panelTitle"><div><h2>{v.title}</h2><p>{v.scheduled_date}</p></div><div className="status completed">verified</div></div><div className="proofGrid">{proof.map(p=><figure key={p.id}><img src={p.file_url}/><figcaption>{p.proof_type}</figcaption></figure>)}</div></section>})}{!visits.length&&<Empty title="No verified services yet" text="Completed and verified missions will appear here."/>}</div>;
}

function CustomerRequests({profile,data,reload}) {
  const [open,setOpen]=useState(false);
  const [form,setForm]=useState({facility_id:'',request_type:'additional_service',title:'',description:''});
  const [message,setMessage]=useState('');
  const facilities=data.facilities.filter(f=>f.customer_id===profile.customer_id);
  async function save() {
    const {error}=await createCustomerRequest(profile.company_id,profile,form);
    if(error) return setMessage(error.message);
    setOpen(false); reload();
  }
  const requests=data.requests.filter(r=>r.customer_id===profile.customer_id);
  return <div className="page"><div className="pageHeader"><div><p className="eyebrow">Customer requests</p><h1>Request service</h1><p>Ask for additional cleaning or report a need.</p></div><Button onClick={()=>setOpen(true)}><Plus size={16}/> New request</Button></div><section className="panel">{requests.map(r=><div className="issueRow" key={r.id}><Wrench size={18}/><div><strong>{r.title}</strong><span>{r.description}</span></div><div className={`status ${r.status}`}>{r.status}</div></div>)}{!requests.length&&<Empty title="No requests" text="Your requests will appear here."/>}</section><Modal open={open} title="New service request" onClose={()=>setOpen(false)}><div className="form"><label>Facility<select value={form.facility_id} onChange={e=>setForm({...form,facility_id:e.target.value})}><option value="">Select...</option>{facilities.map(f=><option key={f.id} value={f.id}>{f.name}</option>)}</select></label><label>Type<select value={form.request_type} onChange={e=>setForm({...form,request_type:e.target.value})}><option value="additional_service">Additional service</option><option value="issue">Report issue</option><option value="schedule_change">Schedule change</option></select></label><label>Title<input value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/></label><label>Description<textarea value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></label>{message&&<div className="notice">{message}</div>}<Button onClick={save}>Submit request</Button></div></Modal></div>;
}

export function App() {
  const [session,setSession]=useState(null);
  const [profile,setProfile]=useState(null);
  const [data,setData]=useState(empty);
  const [loading,setLoading]=useState(true);
  const [portal,setPortal]=useState('admin');
  const [page,setPage]=useState('overview');

  async function bootstrap() {
    if(!supabase) return setLoading(false);
    const {data:{session}}=await supabase.auth.getSession();
    setSession(session);
    if(session?.user) {
      const p=await getMyProfile(session.user.id);
      setProfile(p);
      if(p) {
        const rolePortal=p.role==='customer'?'customer':p.role==='employee'?'employee':'admin';
        setPortal(rolePortal);
        setPage(rolePortal==='admin'?'overview':rolePortal==='employee'?'employee-home':'customer-home');
        setData(await loadWorkspace(p));
      }
    }
    setLoading(false);
  }

  async function reload() {
    const p=await getMyProfile(session.user.id);
    setProfile(p);
    if(p) setData(await loadWorkspace(p));
  }

  useEffect(()=>{bootstrap(); if(supabase){const {data:l}=supabase.auth.onAuthStateChange(()=>bootstrap());return()=>l.subscription.unsubscribe();}},[]);

  if(loading) return <div className="loading">Loading FacilityOS…</div>;
  if(!session) return <Login onReady={bootstrap}/>;
  if(!profile?.company_id) return <Setup session={session} onDone={reload}/>;

  let content;
  if(portal==='admin') {
    if(page==='overview') content=<AdminOverview data={data} setPage={setPage}/>;
    else if(page==='customers') content=<CustomersPage data={data} companyId={profile.company_id} reload={reload}/>;
    else if(page==='facilities') content=<FacilitiesPage data={data} companyId={profile.company_id} reload={reload}/>;
    else if(page==='calendar') content=<CalendarPage data={data} companyId={profile.company_id} reload={reload}/>;
    else if(page==='employees') content=<EmployeesPage data={data} companyId={profile.company_id} reload={reload}/>;
    else if(page==='issues') content=<IssuesPage data={data}/>;
    else content=<SettingsPage companyId={profile.company_id} reload={reload}/>;
  } else if(portal==='employee') {
    content=<EmployeeHome profile={profile} data={data} reload={reload}/>;
  } else {
    if(page==='customer-proof') content=<CustomerProof profile={profile} data={data}/>;
    else if(page==='customer-requests') content=<CustomerRequests profile={profile} data={data} reload={reload}/>;
    else content=<CustomerHome profile={profile} data={data}/>;
  }

  return <Shell profile={profile} portal={portal} setPortal={setPortal} page={page} setPage={setPage}>{content}</Shell>;
}
