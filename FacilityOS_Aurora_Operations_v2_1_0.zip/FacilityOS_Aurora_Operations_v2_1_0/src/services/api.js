import { supabase } from './supabase';

export async function getMyProfile(userId) {
  if (!supabase || !userId) return null;
  const { data } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();
  return data || null;
}

export async function saveMyProfile(user, fields) {
  return supabase.from('profiles').upsert({
    id: user.id,
    full_name: fields.full_name || user.email,
    role: fields.role || 'owner',
    phone: fields.phone || null,
    company_id: fields.company_id || null,
    customer_id: fields.customer_id || null
  });
}

export async function createCompany(user, name) {
  const { data, error } = await supabase
    .from('companies')
    .insert({ name, brand_color:'#111111' })
    .select()
    .single();

  if (error) return { error };

  const { error: profileError } = await supabase
    .from('profiles')
    .upsert({
      id:user.id,
      company_id:data.id,
      full_name:user.email,
      role:'owner'
    });

  return { data, error:profileError };
}

export async function loadWorkspace(profile) {
  if (!profile?.company_id) return {
    customers:[], facilities:[], people:[], plans:[], visits:[],
    tasks:[], proof:[], issues:[], requests:[]
  };

  const companyId = profile.company_id;

  const [
    customers, facilities, people, plans, visits, tasks, proof, issues, requests
  ] = await Promise.all([
    supabase.from('customers').select('*').eq('company_id',companyId).neq('status','archived').order('name'),
    supabase.from('facilities').select('*').eq('company_id',companyId).neq('status','archived').order('name'),
    supabase.from('profiles').select('*').eq('company_id',companyId).order('full_name'),
    supabase.from('service_plans').select('*').eq('company_id',companyId).neq('status','archived').order('created_at',{ascending:false}),
    supabase.from('service_visits').select('*').eq('company_id',companyId).neq('status','archived').order('scheduled_date',{ascending:true}),
    supabase.from('mission_tasks').select('*').eq('company_id',companyId).order('sort_order'),
    supabase.from('visit_proof').select('*').eq('company_id',companyId).order('created_at',{ascending:false}),
    supabase.from('facility_issues').select('*').eq('company_id',companyId).order('created_at',{ascending:false}),
    supabase.from('customer_requests').select('*').eq('company_id',companyId).order('created_at',{ascending:false})
  ]);

  return {
    customers:customers.data||[],
    facilities:facilities.data||[],
    people:people.data||[],
    plans:plans.data||[],
    visits:visits.data||[],
    tasks:tasks.data||[],
    proof:proof.data||[],
    issues:issues.data||[],
    requests:requests.data||[]
  };
}

export async function createCustomer(companyId, form) {
  return supabase.from('customers').insert({
    company_id:companyId,
    name:form.name,
    customer_type:form.customer_type||'commercial',
    status:'active',
    email:form.email||null,
    phone:form.phone||null,
    address:form.address||null,
    monthly_value:Number(form.monthly_value||0),
    health_score:100,
    readiness_score:35
  }).select().single();
}

export async function createFacility(companyId, form) {
  return supabase.from('facilities').insert({
    company_id:companyId,
    customer_id:form.customer_id,
    name:form.name,
    facility_type:form.facility_type||'office',
    address:form.address||null,
    access_notes:form.access_notes||null,
    restroom_count:Number(form.restroom_count||0),
    floor_type:form.floor_type||null,
    estimated_minutes:Number(form.estimated_minutes||60),
    status:'active',
    health_score:100,
    readiness_score:50
  }).select().single();
}

export async function createPerson(companyId, form) {
  if (!form.user_id) {
    return { error:{ message:'Create the login in Supabase Authentication first, then paste the User ID here.' } };
  }

  return supabase.from('profiles').upsert({
    id:form.user_id,
    company_id:companyId,
    customer_id:form.role==='customer' ? form.customer_id : null,
    full_name:form.full_name,
    role:form.role,
    phone:form.phone||null,
    status:'active'
  }).select().single();
}

export async function createServicePlan(companyId, form) {
  return supabase.from('service_plans').insert({
    company_id:companyId,
    customer_id:form.customer_id,
    facility_id:form.facility_id,
    name:form.name,
    frequency:form.frequency,
    weekdays:form.weekdays||[],
    start_date:form.start_date,
    default_time:form.default_time||'18:00',
    assigned_to_profile_id:form.assigned_to_profile_id||null,
    estimated_minutes:Number(form.estimated_minutes||90),
    visit_price:Number(form.visit_price||0),
    status:'active'
  }).select().single();
}

function addDays(date, days) {
  const next = new Date(date);
  next.setDate(next.getDate()+days);
  return next;
}

function isoDate(date) {
  return date.toISOString().slice(0,10);
}

function matchesFrequency(date, plan, start) {
  const day = date.getDay();
  const weekdays = (plan.weekdays||[]).map(Number);
  const diffDays = Math.floor((date-start)/(1000*60*60*24));

  if (plan.frequency==='weekly') return weekdays.includes(day);
  if (plan.frequency==='biweekly') return weekdays.includes(day) && Math.floor(diffDays/7)%2===0;
  if (plan.frequency==='monthly') return date.getDate()===start.getDate();
  if (plan.frequency==='quarterly') {
    const monthDiff=(date.getFullYear()-start.getFullYear())*12+date.getMonth()-start.getMonth();
    return monthDiff>=0 && monthDiff%3===0 && date.getDate()===start.getDate();
  }
  return false;
}

export async function generateVisits(companyId, plan, months=12) {
  const start = new Date(`${plan.start_date}T12:00:00`);
  const end = new Date(start);
  end.setMonth(end.getMonth()+months);

  const rows=[];
  for(let d=new Date(start); d<=end; d=addDays(d,1)) {
    if(matchesFrequency(d, plan, start)) {
      rows.push({
        company_id:companyId,
        customer_id:plan.customer_id,
        facility_id:plan.facility_id,
        service_plan_id:plan.id,
        title:plan.name,
        scheduled_date:isoDate(d),
        scheduled_time:plan.default_time,
        assigned_to_profile_id:plan.assigned_to_profile_id,
        status:'scheduled',
        verification_status:'not_started',
        estimated_minutes:plan.estimated_minutes
      });
    }
  }

  if(!rows.length) return { error:{ message:'No dates matched this service plan.' } };

  const { data, error } = await supabase.from('service_visits').insert(rows).select();
  if(error) return { error };

  const taskTemplates = [
    ['Check in and review access notes',1,false],
    ['Upload before photos',2,true],
    ['Empty trash and replace liners',3,false],
    ['Clean and disinfect high-touch surfaces',4,false],
    ['Clean restrooms',5,false],
    ['Vacuum and mop floors',6,false],
    ['Report facility issues',7,false],
    ['Upload after photos',8,true],
    ['Complete final quality inspection',9,false]
  ];

  const taskRows=[];
  for(const visit of data) {
    for(const [title,sort_order,requires_proof] of taskTemplates) {
      taskRows.push({
        company_id:companyId,
        service_visit_id:visit.id,
        title, sort_order, requires_proof, status:'pending'
      });
    }
  }
  await supabase.from('mission_tasks').insert(taskRows);

  return { data, error:null };
}

export async function updateVisit(id, updates) {
  return supabase.from('service_visits').update(updates).eq('id',id).select().single();
}

export async function toggleTask(task) {
  const done = task.status !== 'completed';
  return supabase.from('mission_tasks').update({
    status:done?'completed':'pending',
    completed_at:done?new Date().toISOString():null
  }).eq('id',task.id);
}

export async function uploadProof(companyId, visitId, userId, file, proofType) {
  const safe = file.name.replace(/[^a-zA-Z0-9._-]/g,'_');
  const path = `${companyId}/${visitId}/${Date.now()}-${safe}`;

  const { error:uploadError } = await supabase.storage
    .from('proof-photos')
    .upload(path,file,{ upsert:false });

  if(uploadError) return { error:uploadError };

  const { data:publicData } = supabase.storage.from('proof-photos').getPublicUrl(path);

  return supabase.from('visit_proof').insert({
    company_id:companyId,
    service_visit_id:visitId,
    uploaded_by_profile_id:userId,
    proof_type:proofType,
    file_url:publicData.publicUrl,
    status:'uploaded'
  }).select().single();
}

export async function createIssue(companyId, form, profileId) {
  return supabase.from('facility_issues').insert({
    company_id:companyId,
    customer_id:form.customer_id,
    facility_id:form.facility_id,
    service_visit_id:form.service_visit_id||null,
    reported_by_profile_id:profileId,
    title:form.title,
    description:form.description||null,
    priority:form.priority||'medium',
    status:'open'
  }).select().single();
}

export async function createCustomerRequest(companyId, profile, form) {
  return supabase.from('customer_requests').insert({
    company_id:companyId,
    customer_id:profile.customer_id,
    requested_by_profile_id:profile.id,
    facility_id:form.facility_id||null,
    request_type:form.request_type||'additional_service',
    title:form.title,
    description:form.description||null,
    status:'new'
  }).select().single();
}

export async function seedMIP(companyId) {
  const existing = await supabase.from('customers').select('id').eq('company_id',companyId).eq('name','MIP Cargo Express').maybeSingle();
  if(existing.data) return { error:{ message:'MIP starter profile already exists.' } };

  const { data:customer, error:customerError } = await supabase.from('customers').insert({
    company_id:companyId,
    name:'MIP Cargo Express',
    customer_type:'logistics',
    status:'active',
    monthly_value:280,
    health_score:100,
    readiness_score:80
  }).select().single();
  if(customerError) return { error:customerError };

  const { data:facility, error:facilityError } = await supabase.from('facilities').insert({
    company_id:companyId,
    customer_id:customer.id,
    name:'MIP Cargo Express — Office',
    facility_type:'office',
    address:'Miami, Florida',
    access_notes:'Warehouse-adjacent office. Prioritize visible floors, restroom presentation, entry, conference room, and kitchen.',
    restroom_count:3,
    floor_type:'LVP / faux wood hard floor',
    estimated_minutes:150,
    status:'active',
    health_score:100,
    readiness_score:85
  }).select().single();
  if(facilityError) return { error:facilityError };

  const { data:plan, error:planError } = await supabase.from('service_plans').insert({
    company_id:companyId,
    customer_id:customer.id,
    facility_id:facility.id,
    name:'MIP Weekly Office Cleaning',
    frequency:'weekly',
    weekdays:[6],
    start_date:new Date().toISOString().slice(0,10),
    default_time:'09:00',
    estimated_minutes:150,
    visit_price:70,
    status:'active'
  }).select().single();
  if(planError) return { error:planError };

  return { data:{customer,facility,plan}, error:null };
}
