import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { supabase, isSupabaseConfigured } from '../services/supabaseClient';
import { getProfile, saveProfile as saveProfileRecord } from '../services/dataService';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  async function reloadProfile(userId = session?.user?.id) {
    if (!userId) return setProfile(null);
    const nextProfile = await getProfile(userId);
    setProfile(nextProfile);
  }

  useEffect(() => {
    if (!supabase) {
      setLoading(false);
      return;
    }

    supabase.auth.getSession().then(async ({ data }) => {
      setSession(data.session || null);
      if (data.session?.user?.id) await reloadProfile(data.session.user.id);
      setLoading(false);
    });

    const { data: listener } = supabase.auth.onAuthStateChange(async (_event, nextSession) => {
      setSession(nextSession);
      if (nextSession?.user?.id) await reloadProfile(nextSession.user.id);
      else setProfile(null);
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  async function signIn(email, password) {
    if (!supabase) return { error: { message: 'Supabase not configured.' } };
    return supabase.auth.signInWithPassword({ email, password });
  }

  async function signUp(email, password) {
    if (!supabase) return { error: { message: 'Supabase not configured.' } };
    return supabase.auth.signUp({ email, password });
  }

  async function signOut() {
    if (supabase) await supabase.auth.signOut();
  }

  async function saveProfile(fullName) {
    const { error } = await saveProfileRecord({ user: session?.user, fullName });
    if (!error) await reloadProfile();
    return { error };
  }

  const value = useMemo(() => ({
    isSupabaseConfigured,
    session,
    profile,
    loading,
    signIn,
    signUp,
    signOut,
    saveProfile,
    reloadProfile
  }), [session, profile, loading]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}
