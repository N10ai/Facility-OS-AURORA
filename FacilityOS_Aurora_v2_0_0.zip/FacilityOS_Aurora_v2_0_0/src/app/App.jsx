import { useEffect, useMemo, useState } from 'react';
import { Sparkles } from 'lucide-react';
import { useAuth } from './AuthProvider';
import { AppShell } from '../components/shell/AppShell';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { CommandPalette } from '../modules/search/CommandPalette';
import { Dashboard } from '../modules/dashboard/Dashboard';
import { Customers } from '../modules/customers/Customers';
import { Facilities } from '../modules/facilities/Facilities';
import { CalendarPage } from '../modules/calendar/Calendar';
import { createCompany, listCustomers, listFacilities, listServiceVisits } from '../services/dataService';

function SettingsPage({ profile, session, reloadProfile }) {
  const [name, setName] = useState('');
  const [message, setMessage] = useState('');

  async function saveCompany() {
    if (!session?.user) return setMessage('Login first.');
    const { error } = await createCompany({ name, user: session.user });
    if (error) return setMessage(error.message);
    await reloadProfile();
    setMessage('Company created and linked.');
  }

  return (
    <div className="pageGrid">
      <div className="workspaceHeader">
        <div><p className="eyebrow">Settings</p><h1>Workspace setup</h1><p>Set up your company workspace and account profile.</p></div>
      </div>
      <Card>
        <h2>Company</h2>
        <p>Current company: <b>{profile?.companies?.name || 'Not linked yet'}</b></p>
        <div className="formStack narrow">
          <label>Company name<input value={name} onChange={event => setName(event.target.value)} placeholder="N10 Facility Services"/></label>
          <Button onClick={saveCompany}>Create/link company</Button>
          {message && <div className="notice">{message}</div>}
        </div>
      </Card>
    </div>
  );
}

function Placeholder({ title, description }) {
  return (
    <div className="pageGrid">
      <div className="workspaceHeader">
        <div><p className="eyebrow">Aurora Workspace</p><h1>{title}</h1><p>{description}</p></div>
      </div>
      <Card>
        <div className="emptyState">
          <div className="emptyOrb"><Sparkles size={28}/></div>
          <h3>Designed, not rushed</h3>
          <p>This workspace will be rebuilt after Aurora’s design system is stable.</p>
        </div>
      </Card>
    </div>
  );
}

export function App() {
  const { profile, session, reloadProfile } = useAuth();
  const [activePage, setActivePage] = useState('dashboard');
  const [customers, setCustomers] = useState([]);
  const [facilities, setFacilities] = useState([]);
  const [visits, setVisits] = useState([]);
  const [commandOpen, setCommandOpen] = useState(false);

  const companyId = profile?.company_id;

  async function reloadData() {
    if (!companyId) {
      setCustomers([]);
      setFacilities([]);
      setVisits([]);
      return;
    }

    const [customerResult, facilityResult, visitResult] = await Promise.all([
      listCustomers(companyId),
      listFacilities(companyId),
      listServiceVisits(companyId)
    ]);

    setCustomers(customerResult.data || []);
    setFacilities(facilityResult.data || []);
    setVisits(visitResult.data || []);
  }

  useEffect(() => { reloadData(); }, [companyId]);

  useEffect(() => {
    function onKey(event) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setCommandOpen(true);
      }
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const page = useMemo(() => {
    if (activePage === 'dashboard') return <Dashboard customers={customers} facilities={facilities} visits={visits} setActivePage={setActivePage}/>;
    if (activePage === 'customers') return <Customers customers={customers} facilities={facilities} companyId={companyId} reload={reloadData}/>;
    if (activePage === 'facilities') return <Facilities facilities={facilities} customers={customers} visits={visits} companyId={companyId} reload={reloadData}/>;
    if (activePage === 'calendar' || activePage === 'operations') return <CalendarPage visits={visits}/>;
    if (activePage === 'settings') return <SettingsPage profile={profile} session={session} reloadProfile={reloadProfile}/>;
    if (activePage === 'reports') return <Placeholder title="Reports" description="Beautiful customer-ready reports with photos, charts, notes, and signatures." />;
    if (activePage === 'ai') return <Placeholder title="FacilityOS AI" description="AI command center for scheduling, quotes, reports, summaries, and maintenance prediction." />;
    return <Dashboard customers={customers} facilities={facilities} visits={visits} setActivePage={setActivePage}/>;
  }, [activePage, customers, facilities, visits, companyId, profile, session]);

  return (
    <>
      <AppShell activePage={activePage} setActivePage={setActivePage} onSearch={() => setCommandOpen(true)}>
        {page}
      </AppShell>
      <CommandPalette open={commandOpen} onClose={() => setCommandOpen(false)} customers={customers} facilities={facilities} visits={visits} onSelect={setActivePage}/>
    </>
  );
}
