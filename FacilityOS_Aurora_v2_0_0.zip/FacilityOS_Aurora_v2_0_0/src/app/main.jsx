import React from 'react';
import { createRoot } from 'react-dom/client';
import { AuthProvider } from './AuthProvider';
import { App } from './App';
import '../styles/aurora.css';

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AuthProvider>
      <App/>
    </AuthProvider>
  </React.StrictMode>
);
