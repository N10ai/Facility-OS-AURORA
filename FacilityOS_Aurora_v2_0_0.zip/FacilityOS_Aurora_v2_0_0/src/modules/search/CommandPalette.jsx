import { Search, X } from 'lucide-react';

export function CommandPalette({ open, onClose, customers, facilities, visits, onSelect }) {
  if (!open) return null;

  const results = [
    ...customers.map(item => ({ type: 'Customer', label: item.name, page: 'customers' })),
    ...facilities.map(item => ({ type: 'Facility', label: item.name, page: 'facilities' })),
    ...visits.map(item => ({ type: 'Visit', label: item.title, page: 'operations' }))
  ].slice(0, 12);

  return (
    <div className="commandBackdrop">
      <section className="commandBox">
        <div className="commandInput">
          <Search size={20}/>
          <input autoFocus placeholder="Search customers, facilities, visits..." />
          <button onClick={onClose}><X size={18}/></button>
        </div>

        <div className="commandResults">
          {results.map((result, index) => (
            <button key={`${result.type}-${result.label}-${index}`} onClick={() => { onSelect(result.page); onClose(); }}>
              <span>{result.type}</span>
              <strong>{result.label}</strong>
            </button>
          ))}
          {!results.length && <p>No records yet.</p>}
        </div>
      </section>
    </div>
  );
}
