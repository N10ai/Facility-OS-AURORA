import { useMemo, useState } from 'react';
import { Archive, Building2, CalendarDays, MapPin, Plus, Search } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Card, StatCard } from '../../components/ui/Card';
import { Modal } from '../../components/ui/Modal';
import { Badge } from '../../components/ui/Badge';
import { EmptyState } from '../../components/ui/EmptyState';
import { archiveFacility, createFacility, updateFacility } from '../../services/dataService';

function FacilityForm({ initial, customers, onCancel, onSave }) {
  const [form, setForm] = useState(initial || { customer_id: '', name: '', facility_type: 'office', address: '', access_notes: '' });
  const [message, setMessage] = useState('');

  async function save() {
    if (!form.name) return setMessage('Facility name is required.');
    await onSave(form);
  }

  return (
    <div className="formStack">
      <label>Customer<select value={form.customer_id || ''} onChange={event => setForm({...form, customer_id: event.target.value})}><option value="">Select customer...</option>{customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
      <label>Facility name<input value={form.name || ''} onChange={event => setForm({...form, name: event.target.value})}/></label>
      <div className="formGrid">
        <label>Type<select value={form.facility_type || 'office'} onChange={event => setForm({...form, facility_type: event.target.value})}><option>office</option><option>warehouse</option><option>medical</option><option>restaurant</option><option>retail</option></select></label>
        <label>Address<input value={form.address || ''} onChange={event => setForm({...form, address: event.target.value})}/></label>
      </div>
      <label>Access notes<textarea value={form.access_notes || ''} onChange={event => setForm({...form, access_notes: event.target.value})}/></label>
      {message && <div className="notice">{message}</div>}
      <div className="buttonRow"><Button variant="ghost" onClick={onCancel}>Cancel</Button><Button onClick={save}>Save facility</Button></div>
    </div>
  );
}

export function Facilities({ facilities, customers, visits, companyId, reload }) {
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(null);
  const [modal, setModal] = useState(null);
  const [message, setMessage] = useState('');

  const customerMap = Object.fromEntries(customers.map(c => [c.id, c.name]));
  const filtered = useMemo(() => facilities.filter(f => f.name?.toLowerCase().includes(query.toLowerCase())), [facilities, query]);

  async function saveFacility(payload) {
    const result = modal?.mode === 'edit' ? await updateFacility(modal.facility.id, payload) : await createFacility(companyId, payload);
    if (result.error) return setMessage(result.error.message);
    setModal(null);
    setSelected(result.data || modal.facility);
    await reload();
  }

  async function doArchive(facility) {
    const { error } = await archiveFacility(facility.id);
    if (error) return setMessage(error.message);
    setSelected(null);
    await reload();
  }

  if (selected) {
    const facilityVisits = visits.filter(v => v.facility_id === selected.id);
    return (
      <div className="pageGrid">
        <div className="workspaceHeader">
          <div>
            <button className="textBack" onClick={() => setSelected(null)}>← Facilities</button>
            <h1>{selected.name}</h1>
            <p>{customerMap[selected.customer_id] || 'No customer'} · {selected.facility_type || 'facility'}</p>
          </div>
          <div className="buttonRow">
            <Button variant="secondary" onClick={() => setModal({ mode: 'edit', facility: selected })}>Edit</Button>
            <Button variant="ghost" onClick={() => doArchive(selected)}><Archive size={16}/> Archive</Button>
          </div>
        </div>

        <div className="statsRow">
          <StatCard icon={Building2} label="Health score" value={`${selected.health_score || 100}%`} note="Digital twin"/>
          <StatCard icon={CalendarDays} label="Visits" value={facilityVisits.length} note="Scheduled history"/>
          <StatCard icon={MapPin} label="Location" value={selected.address ? 'Set' : 'Missing'} note={selected.address || 'No address'}/>
          <StatCard label="Readiness" value={`${selected.readiness_score || 45}%`} note="Setup progress"/>
        </div>

        <div className="columns">
          <Card className="largeCard">
            <div className="sectionTitle"><h2>Facility timeline</h2></div>
            <div className="timeline">
              <div className="timelineRow"><div className="timeBubble">Now</div><div><strong>Digital twin created</strong><span>Service calendar, photos, assets, and issues will live here.</span></div></div>
              {facilityVisits.slice(0,4).map(v => <div className="timelineRow" key={v.id}><div className="timeBubble">{v.scheduled_date || '—'}</div><div><strong>{v.title}</strong><span>{v.status || 'scheduled'}</span></div></div>)}
            </div>
          </Card>
          <Card><h2>AI facility brief</h2><p>This workspace will become the building’s operating center: schedule, photos, floor plans, assets, issues, documents, and AI insights.</p><Badge>Digital Twin</Badge></Card>
        </div>

        <Modal open={!!modal} title="Edit facility" onClose={() => setModal(null)}><FacilityForm initial={modal?.facility} customers={customers} onCancel={() => setModal(null)} onSave={saveFacility}/>{message && <div className="notice">{message}</div>}</Modal>
      </div>
    );
  }

  return (
    <div className="pageGrid">
      <div className="workspaceHeader">
        <div>
          <p className="eyebrow">Facility Digital Twins</p>
          <h1>Facilities</h1>
          <p>Each site becomes a clean building workspace with history, schedule, photos, and issues.</p>
        </div>
        <Button onClick={() => setModal({ mode: 'create' })}><Plus size={16}/> New facility</Button>
      </div>

      <div className="toolbar"><div className="softSearch"><Search size={18}/><input value={query} onChange={event => setQuery(event.target.value)} placeholder="Search facilities..."/></div></div>

      <div className="objectGrid">
        {filtered.map(facility => (
          <button className="objectCard" key={facility.id} onClick={() => setSelected(facility)}>
            <div className="objectTop"><div className="objectAvatar"><Building2 size={20}/></div><Badge>{facility.status || 'active'}</Badge></div>
            <h3>{facility.name}</h3>
            <p>{customerMap[facility.customer_id] || 'No customer'} · {facility.facility_type || 'facility'}</p>
            <div className="healthBar"><span style={{ width: `${facility.health_score || 100}%` }}/></div>
            <small>{facility.address || 'No address'}</small>
          </button>
        ))}
      </div>

      {!filtered.length && <EmptyState title="No facilities yet" description="Create a facility digital twin for one of your customers." action={<Button onClick={() => setModal({ mode: 'create' })}>Create facility</Button>}/>}
      <Modal open={!!modal} title="New facility" onClose={() => setModal(null)}><FacilityForm customers={customers} onCancel={() => setModal(null)} onSave={saveFacility}/>{message && <div className="notice">{message}</div>}</Modal>
    </div>
  );
}
