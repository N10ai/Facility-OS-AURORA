import { Activity, AlertTriangle, CalendarDays, CheckCircle2, DollarSign, Sparkles } from 'lucide-react';
import { Card, StatCard } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';

export function Dashboard({ customers, facilities, visits, setActivePage }) {
  const today = new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' });

  return (
    <div className="pageGrid">
      <section className="hero">
        <div>
          <p className="eyebrow">Today · {today}</p>
          <h1>Good afternoon.</h1>
          <p>Manage commercial facilities from one beautiful workspace.</p>
        </div>
        <div className="buttonRow">
          <Button onClick={() => setActivePage('operations')}>Plan work</Button>
          <Button variant="secondary" onClick={() => setActivePage('customers')}>New customer</Button>
        </div>
      </section>

      <div className="statsRow">
        <StatCard icon={CalendarDays} label="Visits scheduled" value={visits.length} note="Active missions"/>
        <StatCard icon={CheckCircle2} label="Customers" value={customers.length} note="Active accounts"/>
        <StatCard icon={Activity} label="Facilities" value={facilities.length} note="Digital twins"/>
        <StatCard icon={DollarSign} label="Revenue pulse" value="$0" note="Connect billing later"/>
      </div>

      <div className="columns">
        <Card className="largeCard">
          <div className="sectionTitle">
            <div>
              <p className="eyebrow">Operations</p>
              <h2>Today’s schedule</h2>
            </div>
            <Button variant="ghost" onClick={() => setActivePage('calendar')}>Open calendar</Button>
          </div>

          <div className="timeline">
            {visits.slice(0, 5).map(visit => (
              <div className="timelineRow" key={visit.id}>
                <div className="timeBubble">{visit.scheduled_time || '—'}</div>
                <div>
                  <strong>{visit.title || 'Service visit'}</strong>
                  <span>{visit.scheduled_date || 'No date'} · {visit.assigned_to_name || 'Unassigned'}</span>
                </div>
              </div>
            ))}
            {!visits.length && <p>No service visits scheduled yet.</p>}
          </div>
        </Card>

        <Card>
          <div className="sectionTitle">
            <div>
              <p className="eyebrow">AI Briefing</p>
              <h2>Recommended next actions</h2>
            </div>
            <Sparkles size={22}/>
          </div>
          <div className="recommendations">
            <div><AlertTriangle size={18}/><span>Create service standards before scaling recurring jobs.</span></div>
            <div><CalendarDays size={18}/><span>Use Calendar to plan weekly and monthly work.</span></div>
            <div><CheckCircle2 size={18}/><span>Complete customer and facility profiles.</span></div>
          </div>
        </Card>
      </div>
    </div>
  );
}
