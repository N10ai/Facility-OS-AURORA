import { useMemo, useState } from 'react';
import { Archive, Building2, Mail, Plus, Search } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Card, StatCard } from '../../components/ui/Card';
import { Modal } from '../../components/ui/Modal';
import { Badge } from '../../components/ui/Badge';
import { EmptyState } from '../../components/ui/EmptyState';
import { archiveCustomer, createCustomer, updateCustomer } from '../../services/dataService';

function CustomerForm({ initial, onCancel, onSave }) {
  const [form, setForm] = useState(initial || { name: '', customer_type: 'commercial', status: 'active', email: '', phone: '', address: '', monthly_value: '' });
  const [message, setMessage] = useState('');

  async function save() {
    if (!form.name) return setMessage('Customer name is required.');
    await onSave(form);
  }

  return (
    <div className="formStack">
      <label>Name<input value={form.name || ''} onChange={event => setForm({...form, name: event.target.value})}/></label>
      <div className="formGrid">
        <label>Type<select value={form.customer_type || 'commercial'} onChange={event => setForm({...form, customer_type: event.target.value})}><option>commercial</option><option>medical</option><option>warehouse</option><option>retail</option><option>school</option><option>restaurant</option></select></label>
        <label>Status<select value={form.status || 'active'} onChange={event => setForm({...form, status: event.target.value})}><option>active</option><option>lead</option><option>paused</option><option>cancelled</option></select></label>
        <label>Email<input value={form.email || ''} onChange={event => setForm({...form, email: event.target.value})}/></label>
        <label>Phone<input value={form.phone || ''} onChange={event => setForm({...form, phone: event.target.value})}/></label>
      </div>
      <label>Address<input value={form.address || ''} onChange={event => setForm({...form, address: event.target.value})}/></label>
      <label>Monthly value<input type="number" value={form.monthly_value || ''} onChange={event => setForm({...form, monthly_value: event.target.value})}/></label>
      {message && <div className="notice">{message}</div>}
      <div className="buttonRow"><Button variant="ghost" onClick={onCancel}>Cancel</Button><Button onClick={save}>Save customer</Button></div>
    </div>
  );
}

export function Customers({ customers, facilities, companyId, reload }) {
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(null);
  const [modal, setModal] = useState(null);
  const [message, setMessage] = useState('');

  const filtered = useMemo(() => customers.filter(customer => customer.name?.toLowerCase().includes(query.toLowerCase())), [customers, query]);

  async function saveCustomer(payload) {
    const result = modal?.mode === 'edit' ? await updateCustomer(modal.customer.id, payload) : await createCustomer(companyId, payload);
    if (result.error) return setMessage(result.error.message);
    setModal(null);
    setSelected(result.data || modal.customer);
    await reload();
  }

  async function doArchive(customer) {
    const { error } = await archiveCustomer(customer.id);
    if (error) return setMessage(error.message);
    setSelected(null);
    await reload();
  }

  if (selected) {
    const customerFacilities = facilities.filter(f => f.customer_id === selected.id);
    return (
      <div className="pageGrid">
        <div className="workspaceHeader">
          <div>
            <button className="textBack" onClick={() => setSelected(null)}>← Customers</button>
            <h1>{selected.name}</h1>
            <p>{selected.customer_type || 'commercial'} · {selected.status || 'active'}</p>
          </div>
          <div className="buttonRow">
            <Button variant="secondary" onClick={() => setModal({ mode: 'edit', customer: selected })}>Edit</Button>
            <Button variant="ghost" onClick={() => doArchive(selected)}><Archive size={16}/> Archive</Button>
          </div>
        </div>

        <div className="statsRow">
          <StatCard icon={Building2} label="Facilities" value={customerFacilities.length} note="Active sites"/>
          <StatCard icon={Mail} label="Email" value={selected.email || '—'} note="Primary contact"/>
          <StatCard label="Health" value={`${selected.health_score || 100}%`} note="Customer score"/>
          <StatCard label="Monthly value" value={`$${selected.monthly_value || 0}`} note="Estimated"/>
        </div>

        <div className="columns">
          <Card className="largeCard">
            <div className="sectionTitle"><h2>Facilities</h2></div>
            <div className="miniCardGrid">
              {customerFacilities.map(facility => <div className="miniCard" key={facility.id}><strong>{facility.name}</strong><span>{facility.facility_type || 'facility'} · {facility.address || 'No address'}</span></div>)}
              {!customerFacilities.length && <p>No facilities linked yet.</p>}
            </div>
          </Card>
          <Card><h2>Customer briefing</h2><p>This workspace will hold contacts, facilities, documents, invoices, service plans, history, and AI insights.</p><Badge>Workspace</Badge></Card>
        </div>

        <Modal open={!!modal} title="Edit customer" onClose={() => setModal(null)}>
          <CustomerForm initial={modal?.customer} onCancel={() => setModal(null)} onSave={saveCustomer}/>
          {message && <div className="notice">{message}</div>}
        </Modal>
      </div>
    );
  }

  return (
    <div className="pageGrid">
      <div className="workspaceHeader">
        <div>
          <p className="eyebrow">Customer Workspace</p>
          <h1>Customers</h1>
          <p>Clean customer cards, simple search, and one workspace per account.</p>
        </div>
        <Button onClick={() => setModal({ mode: 'create' })}><Plus size={16}/> New customer</Button>
      </div>

      <div className="toolbar"><div className="softSearch"><Search size={18}/><input value={query} onChange={event => setQuery(event.target.value)} placeholder="Search customers..."/></div></div>

      <div className="objectGrid">
        {filtered.map(customer => (
          <button className="objectCard" key={customer.id} onClick={() => setSelected(customer)}>
            <div className="objectTop"><div className="objectAvatar">{customer.name?.slice(0,1) || 'C'}</div><Badge>{customer.status || 'active'}</Badge></div>
            <h3>{customer.name}</h3>
            <p>{customer.customer_type || 'commercial'} · ${customer.monthly_value || 0}/mo</p>
            <div className="healthBar"><span style={{ width: `${customer.health_score || 100}%` }}/></div>
            <small>Health {customer.health_score || 100}%</small>
          </button>
        ))}
      </div>

      {!filtered.length && <EmptyState title="No customers yet" description="Create your first customer workspace." action={<Button onClick={() => setModal({ mode: 'create' })}>Create customer</Button>}/>}
      <Modal open={!!modal} title="New customer" onClose={() => setModal(null)}><CustomerForm onCancel={() => setModal(null)} onSave={saveCustomer}/>{message && <div className="notice">{message}</div>}</Modal>
    </div>
  );
}
