import { CalendarDays, Plus } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';

const days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];

export function CalendarPage({ visits }) {
  return (
    <div className="pageGrid">
      <div className="workspaceHeader">
        <div>
          <p className="eyebrow">Planning Workspace</p>
          <h1>Calendar</h1>
          <p>Aurora’s future scheduling center: recurring services, drag-and-drop planning, and year generation.</p>
        </div>
        <Button><Plus size={16}/> New plan</Button>
      </div>

      <Card>
        <div className="calendarHeader">
          <div>
            <h2>This week</h2>
            <p>Recurring service planning will become one of FacilityOS’ flagship features.</p>
          </div>
          <Badge>Preview</Badge>
        </div>

        <div className="weekGrid">
          {days.map((day, index) => (
            <div className="dayColumn" key={day}>
              <strong>{day}</strong>
              <span>{index + 8}</span>
              {visits.filter((_, i) => i % 7 === index).slice(0,2).map(visit => (
                <div className="calendarVisit" key={visit.id}><CalendarDays size={14}/><span>{visit.title}</span></div>
              ))}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
