import { useMemo, useState } from 'react';
import { Bell, Building2, CalendarDays, Command, Home, LineChart, LogOut, Menu, Search, Settings, Sparkles, UsersRound, X } from 'lucide-react';
import { useAuth } from '../../app/AuthProvider';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';

const navItems = [
  { key: 'dashboard', label: 'Dashboard', icon: Home },
  { key: 'operations', label: 'Operations', icon: CalendarDays },
  { key: 'customers', label: 'Customers', icon: UsersRound },
  { key: 'facilities', label: 'Facilities', icon: Building2 },
  { key: 'calendar', label: 'Calendar', icon: CalendarDays },
  { key: 'reports', label: 'Reports', icon: LineChart },
  { key: 'settings', label: 'Settings', icon: Settings }
];

export function AppShell({ activePage, setActivePage, children, onSearch }) {
  const { session, profile, signIn, signUp, signOut, saveProfile } = useAuth();
  const [authOpen, setAuthOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [mode, setMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [message, setMessage] = useState('');

  const userLabel = useMemo(() => profile?.full_name || session?.user?.email || 'Sign in', [profile, session]);

  async function submitAuth() {
    const { error } = mode === 'login' ? await signIn(email, password) : await signUp(email, password);
    setMessage(error ? error.message : mode === 'login' ? 'Logged in.' : 'Account created.');
  }

  async function submitProfile() {
    const { error } = await saveProfile(fullName || session?.user?.email);
    setMessage(error ? error.message : 'Profile saved.');
  }

  function go(key) {
    setActivePage(key);
    setMobileOpen(false);
  }

  const Sidebar = (
    <>
      <div className="brand" onClick={() => go('dashboard')}>
        <div className="brandGlyph">F</div>
        <div>
          <strong>FacilityOS</strong>
          <span>Aurora v2.0</span>
        </div>
      </div>

      <nav className="nav">
        {navItems.map(item => {
          const Icon = item.icon;
          return (
            <button key={item.key} className={activePage === item.key ? 'navItem active' : 'navItem'} onClick={() => go(item.key)}>
              <Icon size={18}/>
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="aiPanel">
        <Sparkles size={18}/>
        <strong>FacilityOS AI</strong>
        <p>Ask for schedules, summaries, reports, or next actions.</p>
        <Button variant="light" onClick={() => go('ai')}>Ask AI</Button>
      </div>
    </>
  );

  return (
    <div className="shell">
      <aside className="sidebar">{Sidebar}</aside>

      {mobileOpen && <div className="mobileBackdrop" onClick={() => setMobileOpen(false)} />}
      <aside className={mobileOpen ? 'mobileNav open' : 'mobileNav'}>
        <button className="mobileClose" onClick={() => setMobileOpen(false)}><X size={18}/></button>
        {Sidebar}
      </aside>

      <main className="main">
        <header className="topbar">
          <button className="mobileMenu" onClick={() => setMobileOpen(true)}><Menu size={20}/></button>

          <div className="breadcrumb">
            <span>FacilityOS</span>
            <strong>{navItems.find(x => x.key === activePage)?.label || 'Workspace'}</strong>
          </div>

          <button className="globalSearch" onClick={onSearch}>
            <Search size={18}/>
            <span>Search everything...</span>
            <kbd>⌘K</kbd>
          </button>

          <div className="topActions">
            <button className="roundButton"><Command size={18}/></button>
            <button className="roundButton"><Bell size={18}/></button>
            <button className="profileChip" onClick={() => setAuthOpen(true)}>{userLabel}</button>
          </div>
        </header>

        <div className="workspace">{children}</div>
      </main>

      <Modal open={authOpen} title="FacilityOS Access" onClose={() => setAuthOpen(false)}>
        {!session ? (
          <div className="formStack">
            <div className="segmented">
              <button className={mode === 'login' ? 'active' : ''} onClick={() => setMode('login')}>Login</button>
              <button className={mode === 'signup' ? 'active' : ''} onClick={() => setMode('signup')}>Create</button>
            </div>
            <label>Email<input value={email} onChange={event => setEmail(event.target.value)} /></label>
            <label>Password<input type="password" value={password} onChange={event => setPassword(event.target.value)} /></label>
            <Button onClick={submitAuth}>{mode === 'login' ? 'Login' : 'Create Account'}</Button>
          </div>
        ) : (
          <div className="formStack">
            <p>Logged in as <b>{session.user.email}</b></p>
            <label>Display name<input value={fullName} onChange={event => setFullName(event.target.value)} placeholder={profile?.full_name || session.user.email}/></label>
            <Button onClick={submitProfile}>Save profile</Button>
            <Button variant="ghost" onClick={signOut}><LogOut size={16}/> Logout</Button>
          </div>
        )}
        {message && <div className="notice">{message}</div>}
      </Modal>
    </div>
  );
}
