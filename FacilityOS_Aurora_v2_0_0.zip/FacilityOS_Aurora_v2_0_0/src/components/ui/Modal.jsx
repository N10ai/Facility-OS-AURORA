import { X } from 'lucide-react';

export function Modal({ open, title, children, onClose }) {
  if (!open) return null;
  return (
    <div className="modalBackdrop">
      <section className="modal">
        <button className="modalClose" onClick={onClose}><X size={18}/></button>
        {title && <h2>{title}</h2>}
        {children}
      </section>
    </div>
  );
}
