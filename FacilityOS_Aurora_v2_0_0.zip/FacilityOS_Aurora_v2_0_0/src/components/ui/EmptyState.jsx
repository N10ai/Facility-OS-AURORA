export function EmptyState({ title, description, action }) {
  return (
    <div className="emptyState">
      <div className="emptyOrb" />
      <h3>{title}</h3>
      <p>{description}</p>
      {action}
    </div>
  );
}
