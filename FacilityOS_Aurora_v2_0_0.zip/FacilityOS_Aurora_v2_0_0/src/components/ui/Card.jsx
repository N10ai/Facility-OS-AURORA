export function Card({ children, className = '' }) {
  return <section className={`card ${className}`}>{children}</section>;
}

export function StatCard({ label, value, note, icon: Icon }) {
  return (
    <div className="statCard">
      {Icon && <div className="statIcon"><Icon size={20}/></div>}
      <strong>{value}</strong>
      <span>{label}</span>
      {note && <small>{note}</small>}
    </div>
  );
}
