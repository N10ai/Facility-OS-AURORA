import { supabase } from './supabaseClient';

export async function getProfile(userId) {
  if (!supabase || !userId) return null;
  const { data } = await supabase.from('profiles').select('*, companies(name, brand_color)').eq('id', userId).maybeSingle();
  return data || null;
}

export async function saveProfile({ user, fullName }) {
  if (!user?.id) return { error: { message: 'Login first.' } };
  return supabase.from('profiles').upsert({
    id: user.id,
    full_name: fullName || user.email,
    role: 'owner'
  });
}

export async function createCompany({ name, user }) {
  const { data, error } = await supabase.from('companies').insert({
    name,
    brand_color: '#2563eb'
  }).select().single();

  if (error) return { error };

  const { error: profileError } = await supabase.from('profiles').upsert({
    id: user.id,
    full_name: user.email,
    role: 'owner',
    company_id: data.id
  });

  return { data, error: profileError };
}

export async function listCustomers(companyId) {
  let query = supabase.from('customers').select('*').neq('status', 'archived').order('created_at', { ascending: false });
  if (companyId) query = query.eq('company_id', companyId);
  return query;
}

export async function createCustomer(companyId, payload) {
  return supabase.from('customers').insert({
    company_id: companyId || null,
    name: payload.name,
    customer_type: payload.customer_type || 'commercial',
    status: payload.status || 'active',
    email: payload.email || null,
    phone: payload.phone || null,
    address: payload.address || null,
    monthly_value: Number(payload.monthly_value || 0),
    health_score: 100,
    readiness_score: 35
  }).select().single();
}

export async function updateCustomer(id, payload) {
  return supabase.from('customers').update({
    ...payload,
    monthly_value: Number(payload.monthly_value || 0)
  }).eq('id', id).select().single();
}

export async function archiveCustomer(id) {
  return supabase.from('customers').update({ status: 'archived' }).eq('id', id);
}

export async function listFacilities(companyId) {
  let query = supabase.from('facilities').select('*').neq('status', 'archived').order('created_at', { ascending: false });
  if (companyId) query = query.eq('company_id', companyId);
  return query;
}

export async function createFacility(companyId, payload) {
  return supabase.from('facilities').insert({
    company_id: companyId || null,
    customer_id: payload.customer_id || null,
    name: payload.name,
    facility_type: payload.facility_type || 'office',
    address: payload.address || null,
    access_notes: payload.access_notes || null,
    status: 'active',
    health_score: 100,
    readiness_score: 45
  }).select().single();
}

export async function updateFacility(id, payload) {
  return supabase.from('facilities').update(payload).eq('id', id).select().single();
}

export async function archiveFacility(id) {
  return supabase.from('facilities').update({ status: 'archived' }).eq('id', id);
}

export async function listServiceVisits(companyId) {
  let query = supabase.from('service_visits').select('*').neq('status', 'archived').order('scheduled_date', { ascending: true });
  if (companyId) query = query.eq('company_id', companyId);
  return query;
}
