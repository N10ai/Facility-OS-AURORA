# FacilityOS Aurora v2.0.0

FacilityOS Aurora is the Apple-inspired redesign of FacilityOS.

## Includes

- Blue unified navigation shell
- White rounded workspace
- Aurora design system
- Dashboard
- Customer workspace
- Facility digital twin workspace
- Calendar preview
- Global search / command palette
- Supabase compatibility migration

## Install

Keep your existing `.env`, upload this ZIP to the root of the project, then run:

```bash
unzip -o FacilityOS_Aurora_v2_0_0.zip
cp -r FacilityOS_Aurora_v2_0_0/* .
cp -r FacilityOS_Aurora_v2_0_0/.[!.]* . 2>/dev/null || true
rm -rf FacilityOS_Aurora_v2_0_0

npm install
npm run dev
```

## Supabase

Run:

```text
database/migrations/006_aurora_v2_compatibility.sql
```

## Test

1. Login.
2. Go to Settings and create/link company if needed.
3. Create a customer.
4. Open the customer workspace.
5. Create a facility.
6. Open the facility workspace.
7. Open Calendar.
8. Press Cmd/Ctrl + K for search.
