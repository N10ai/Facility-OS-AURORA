# FacilityOS Product Bible

## Mission

FacilityOS is the operating system for commercial facilities.

## Motto

Connect → Plan → Execute → Verify → Improve

## Core Rule

If it is not verified, it is not complete.

## Aurora Philosophy

FacilityOS should feel like an Apple product for facility management:
simple, premium, calm, and powerful underneath.

## Object Model

- Customers are workspaces.
- Facilities are digital twins.
- Service visits are missions.
- Photos become proof.
- Issues become opportunities.
- AI is present in every workflow.
