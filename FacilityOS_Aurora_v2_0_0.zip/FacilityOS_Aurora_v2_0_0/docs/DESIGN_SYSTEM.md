# FacilityOS Design System — Aurora

## Principles

- Simple before powerful.
- Context over menus.
- One workspace per object.
- White space is a feature.
- If it feels like Excel, redesign it.
- Every visible action should work.

## Visual Language

- Blue navigation shell.
- White rounded workspace.
- Large typography.
- Soft glass surfaces.
- Rounded cards.
- Minimal borders.
- Calm shadows.
- Clear hierarchy.
