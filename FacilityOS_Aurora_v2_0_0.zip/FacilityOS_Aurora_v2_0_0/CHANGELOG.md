# Changelog

## v2.0.0 Aurora

- Complete UI redesign.
- Added blue shell and white workspace.
- Added dashboard, customer workspace, facility workspace, calendar preview.
- Added command palette.
- Preserved Supabase backend compatibility.
