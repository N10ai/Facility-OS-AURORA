-- FacilityOS Aurora v2.0.0 compatibility migration
-- Additive and safe. Repairs common missing columns from older alpha builds.

create extension if not exists "pgcrypto";

create table if not exists companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  legal_name text,
  logo_url text,
  brand_color text default '#2563eb',
  status text default 'active',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  company_id uuid references companies(id) on delete set null,
  full_name text,
  role text not null default 'owner',
  avatar_url text,
  status text default 'active',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists customers (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references companies(id) on delete cascade,
  name text not null,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

alter table public.customers
add column if not exists customer_type text default 'commercial',
add column if not exists status text default 'active',
add column if not exists email text,
add column if not exists phone text,
add column if not exists address text,
add column if not exists monthly_value numeric default 0,
add column if not exists health_score numeric default 100,
add column if not exists readiness_score numeric default 35;

create table if not exists facilities (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references companies(id) on delete cascade,
  customer_id uuid references customers(id) on delete set null,
  name text not null,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

alter table public.facilities
add column if not exists facility_type text default 'office',
add column if not exists address text,
add column if not exists access_notes text,
add column if not exists health_score numeric default 100,
add column if not exists readiness_score numeric default 45,
add column if not exists status text default 'active';

create table if not exists service_visits (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references companies(id) on delete cascade,
  customer_id uuid references customers(id) on delete set null,
  facility_id uuid references facilities(id) on delete set null,
  area_id uuid,
  title text,
  service_type text default 'standard_cleaning',
  scheduled_date date,
  scheduled_time time,
  assigned_to_name text,
  status text default 'scheduled',
  verification_status text default 'not_started',
  notes text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

alter table public.service_visits
add column if not exists company_id uuid references public.companies(id) on delete cascade,
add column if not exists customer_id uuid references public.customers(id) on delete set null,
add column if not exists facility_id uuid references public.facilities(id) on delete set null,
add column if not exists area_id uuid,
add column if not exists title text,
add column if not exists service_type text default 'standard_cleaning',
add column if not exists scheduled_date date,
add column if not exists scheduled_time time,
add column if not exists assigned_to_name text,
add column if not exists status text default 'scheduled',
add column if not exists verification_status text default 'not_started',
add column if not exists notes text,
add column if not exists created_at timestamptz default now(),
add column if not exists updated_at timestamptz default now();

alter table public.companies enable row level security;
alter table public.profiles enable row level security;
alter table public.customers enable row level security;
alter table public.facilities enable row level security;
alter table public.service_visits enable row level security;

drop policy if exists "dev companies all" on public.companies;
create policy "dev companies all" on public.companies for all to anon, authenticated using (true) with check (true);

drop policy if exists "dev profiles all" on public.profiles;
create policy "dev profiles all" on public.profiles for all to anon, authenticated using (true) with check (true);

drop policy if exists "dev customers all" on public.customers;
create policy "dev customers all" on public.customers for all to anon, authenticated using (true) with check (true);

drop policy if exists "dev facilities all" on public.facilities;
create policy "dev facilities all" on public.facilities for all to anon, authenticated using (true) with check (true);

drop policy if exists "dev service_visits all" on public.service_visits;
create policy "dev service_visits all" on public.service_visits for all to anon, authenticated using (true) with check (true);

grant usage on schema public to anon, authenticated;
grant all on all tables in schema public to anon, authenticated;
grant all on all sequences in schema public to anon, authenticated;
