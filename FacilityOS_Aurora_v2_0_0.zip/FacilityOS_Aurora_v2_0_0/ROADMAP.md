# FacilityOS Roadmap

## v2.0 — Aurora Foundation
Design system, shell, dashboard, customer workspace, facility workspace.

## v2.1 — Calendar & Recurring Services
Recurring service plans, year scheduling, drag/drop planning.

## v2.2 — Mission Mode
Technician workflow: check-in, before photos, checklist, issues, after photos, signature.

## v2.3 — Customer Portal
Customer-facing dashboard, quotes, invoices, documents, service history.

## v2.4 — AI Workspace
AI scheduling, AI reports, quote generation, issue classification.
